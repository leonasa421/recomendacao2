<?php

class Compra {

     public function comentar($comemtar){
		global $pdo;
	
 
		$sql = $pdo->prepare("INSERT INTO comenti SET comentar=:comentar");
		$sql->bindValue(":id_usuario", $_SESSION['cLogin']);
		$sql->bindValue(":comentar", $comemtar);
		$sql->execute();


	 }
	 public function comprar($nome, $bank, $telefone, $metodo, $categoria, $endereco) {
		global $pdo;
		$sql = $pdo->prepare("SELECT id FROM usuarios WHERE  nome =:nome");
		$sql->bindValue(":nome", $nome);
		$sql->execute();

		if($sql->rowCount() == 0) {

			$sql = $pdo->prepare("INSERT INTO 
			compra SET nome = :nome, bank = :bank,  
			telefone= :telefone, metodo= :metodo, categoria = :categoria, endereco= :endereco");
			$sql->bindValue(":nome", $nome);
			$sql->bindValue(":bank", $bank);
			$sql->bindValue(":telefone", $telefone);
			$sql->bindValue(":metodo", $metodo);
			$sql->bindValue(":categoria", $categoria);
			$sql->bindValue(":endereco", $endereco);

			$sql->execute();

			return true;

		} else {
			return false;
		}

	}
}
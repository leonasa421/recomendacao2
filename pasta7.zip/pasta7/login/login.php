<?php
session_start();
require 'config.php';
require 'envio.php';

if(!empty($_POST['email'])) {
	$email = addslashes($_POST['email']);
	$senha = ($_POST['senha']);

$u = new Envio($pdo);

	if($u->envioLogin($email, $senha)) {
		header("Location: index.php");
		exit;
	} else {
		echo  " <h1>Usuário e/ou senha estão errados! </h1>";
	}

}

?>
<style>
  .tuy{
    border-radius: 25px;
    text-align: center;
   background-color: whitesmoke ; 
padding: 150px;    
    
}
  .tui{
    text-align: center;
  }
</style>
<h1 class="tui">Login</h1>
<form class="tuy" method="POST">
	E-mail:<br/>
	<input type="email" name="email" /><br/><br/>

	Senha:<br/>
	<input type="password" name="senha" /><br/><br/>
<a href="cadastrar.php">cadastrar-se</a> <br>
	<input type="submit" value="Entrar" />
</form>
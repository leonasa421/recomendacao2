<?php
require 'config.php';
class Envio{

	private $pdo;

	public function __construct($pdo) {
		$this->pdo = $pdo;
	}

	public function envioLogin($email, $senha) {

		$sql = "SELECT * FROM cad WHERE email = :email AND senha = :senha";
		$sql = $this->pdo->prepare($sql);
		$sql->bindValue(":email", $email);
		$sql->bindValue(":senha", $senha);
		$sql->execute();

		if($sql->rowCount() > 0) {
			$sql = $sql->fetch();

			$_SESSION['logd'] = $sql['id'];

			return true;
		}

		return false;
	}
  


 
 






}
 class Cadastrar {
       
  
	public function ca($email, $senha, $telefone, $nome ) {
        global  $pdo;

		$sql = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email");
		$sql->bindValue(':email', $email);
		$sql->execute();

		if($sql->rowCount() === 0) {
			$sql = $pdo->prepare("INSERT INTO usuarios (nome, email, telefone, senha) VALUES (:name, :email, :telefone, :senha)");
			$sql->bindValue(':email', $email);
			$sql->bindValue(':nome', $nome);
			$sql->bindValue(':telefone', $telefone);
			$sql->bindValue(':senha', $senha);
			$sql->execute();
			return true;
		}	else {

			return false;
		}
	} 


 }

<?php require 'pages/header.php'; ?>
<div   style="background-color: rgb(949, 240, 910);" class="container">
	<h1 style="font-size: 55px;"  >Login</h1>
	<?php
	require 'classes/usuarios.class.php';
	$u = new Usuarios();
	if(isset($_POST['email']) && !empty($_POST['email'])) {
		$email = addslashes($_POST['email']);
		$senha = $_POST['senha'];

		if($u->login($email, $senha)) {
			?>
			<script type="text/javascript">window.location.href="./";</script>
			<?php
		} else {
			?>
			<div class="alert alert-danger">
				Usuário e/ou Senha errados!
			</div>
			<?php
		}
	}
	?>
	<form method="POST">
		<div  style="font-size: 25px;"  class="form-group">
			<label for="email">E-mail:</label>
			<input style="border-bottom: 70px; border-radius: 5px;"  type="email" name="email" id="email" class="form-control" />
		</div>
		<div style="font-size: 25px;"  class="form-group">
			<label for="senha">Senha:</label>
			<input style="border-bottom: 70px; border-radius: 5px; "    type="password" name="senha" id="senha" class="form-control" />
		</div> <br>
		<a href="cadastre-se.php">caso nao tenha conta cadastra-se</a> <br> <br>
		<div style="text-align: center; "><input  type="submit" value="Fazer Login" class="btn btn-success" />
</div>
		<br> <br> <br>
	</form>

</div>
<?php require 'pages/footer.php'; ?>
<?php
session_start();
require 'config.php';
 if(empty($_SESSION['lg'])) {

   header("location: login.php");
   exit;
 }

 header("location: footer.php");
exit;
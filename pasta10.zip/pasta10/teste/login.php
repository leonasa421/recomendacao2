<?php

session_start();
require 'config.php';
require 'usuarios.php';


if(!empty($_POST['email'])) {
$email= addslashes($_POST['email']);
$senha = ($_POST['senha']);

$usuarios = new usuarios($pdo);

if($usuarios->efetuarlogin($email, $senha)){
 header("location:index.php");
 exit;
} else {
    echo"usuario ou senha estao errados!";
}



}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1"/>
    <link rel="stylesheet" href="login.css" />
</head>
<body>
    <header>
        <div class="container">
        </div>
    </header>
    <section class="container main">
        <form method="POST"  >


        <h2 style="color: #3569d8; text-align: center; ">Entrar na rede</h2> </br>
      
            <input placeholder="Digite seu e-mail" class="input" type="email" name="email" />

            <input placeholder="Digite sua senha" class="input" type="password" name="senha"/>

         
    
            <input     class="button" type="submit" value="Acessar o sistema" /> </br>

    <a href="">Esqueceu a conta?</a><a href="">cadastrar</a>

        </form>
    </section>
</body>
</html>
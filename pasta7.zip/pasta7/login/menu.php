<?php
require 'envio.php';
 
$c = new Cadastrar();

if(isset($_POST['nome']) && !empty($_POST['nome'])) {
    $nome = addslashes($_POST['nome']);
    $email = addslashes($_POST['email']);
    $senha = $_POST['senha'];
    $telefone = addslashes($_POST['telefone']);


    if(!empty($nome) && !empty($email) && !empty($senha)) {
        if($c->ca($nome, $email, $senha, $telefone)) {

            header("location:azul.php" ); 
             exit;

            } 
            
            else { 
                 header("location: abril.php");
                       exit;
            }
         } 
          else {  header("location:fil.php");
               exit;
         }

}
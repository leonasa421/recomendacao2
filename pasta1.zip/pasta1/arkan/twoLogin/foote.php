 <head>
     <title>Login</title>
    <link href="/assetes/css/signin.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
     integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
</head>
  <link href="assets/css/signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
<main class="form-signin">
<form method="POST">
<h1>Login</h1>
	<?php
	require 'classes/usuarios.class.php';
	$u = new Usuarios();
	if(isset($_POST['email']) && !empty($_POST['email'])) {
		$email = addslashes($_POST['email']);
		$senha = $_POST['senha'];

		if($u->login($email, $senha)) {
			?>
			<script type="text/javascript">window.location.href="./";</script>
			<?php
		} else {
			?>
			<div class="alert alert-danger">
				Usuário e/ou Senha errados!
			</div>
			<?php
		}
	}
	?>

    

    <div class="form-floating">
      <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" name="email" >
      <label for="floatingInput">Email </label>
    </div>
    <div class="form-floating">
      <input type="password" class=" form-control" id="floatingPassword" placeholder="Password" name="senha" >
      <label   for="floatingPassword">Senha</label>
    </div>

    <div class="checkbox mb-3">
      <label>
        <input type="checkbox" value="remember-me"> lembrar
      </label>
    </div>
		<input style="border-radius: 3px; padding: 10px; " type="submit" value="Login" class="w-100 bnt bnt-lgbtn btn-primary" />
   
    <br><br>
    <a href="cadastre-se.php">Ainda não tem conta? Cadastre-se</a>
    <p class="mt-5 mb-3 text-muted">&copy; two.com</p>
  </form>
</main>
  </body>
</html>

<?php
session_start();
require 'config.php';
require 'usuarios.php';

if(!empty($_POST['email'])) {
	$email = addslashes($_POST['email']);
	$senha = md5($_POST['senha']);

	$usuarios = new Usu($pdo);

	if($usuarios->Login($email, $senha)) {
		header("Location: footer.php");
		exit;
	} 
}

?>
<div style="text-align: center;" >

<h1>Login</h1>
<form method="POST">
	E-mail:<br/>
	<input type="email" name="email" /><br/><br/>

	Senha:<br/>
	<input type="password" name="senha" /><br/><br/>

<a href="cadas.php">ainda nao tem conta</a> <br>

	<input type="submit" value="Entrar" />

</form>
</div>
<?php


$name = filter_input(INPUT_POST, 'nome ');
$email = filter_input(INPUT_POST, 'email ');
$senha = filter_input(INPUT_POST, 'senha ');
$idade = filter_input(INPUT_POST, 'idade ');



if($email && $senha  && $nome && $idade ){

}

$_SESSION['flash'] = 'campos invalidos. ';
header("location:cadastro.php");
exit;



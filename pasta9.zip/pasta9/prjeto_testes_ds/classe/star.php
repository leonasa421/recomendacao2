<?php


require 'config.php';

$sql = "SELECT * FROM anuncios";
$sql = $pdo->query($sql);
if($sql->rowCount() > 0) {
	foreach($sql->fetchAll() as $anuncio):
	?>
	<fieldset>
		<strong><?php echo $anuncio['titulo']; ?></strong><br/>
		<a href="votar.php?id=<?php echo $anuncio['id']; ?>&voto=1"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $anuncio['id']; ?>&voto=2"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $anuncio['id']; ?>&voto=3"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $anuncio['id']; ?>&voto=4"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $anuncio['id']; ?>&voto=5"><img src="star.png" height="20" /></a>
		( <?php echo $anuncio['media']; ?> )
	</fieldset>
	<?php
	endforeach;
} 
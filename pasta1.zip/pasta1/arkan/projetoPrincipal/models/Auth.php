 <?php
require_once 'dao/UserDaoMysql.php';

class Auth {
    private $pdo;
    private $base;
    private $dao;
 
    public function __construct(PDO $pdo, $base) {
        $this->pdo = $pdo;
        $this->base = $base;
    }

 
    public function checkToken() {
        if(!empty($_SESSION['token'])) {
            $token = $_SESSION['token'];

            $user = $this->dao->findByToken($token);
            
            if($user) {
                return $user;
            }
        }

        header("Location: ".$this->base."login.php");
        exit;
    }


 public function validateLogin($email, $password){
  $userDao = new UserDaoMysql($this->pdo);
 
 
  $userDao->findByEmail($email);
         
  
           if($user)  {

         if(password_verify($password, $user->password)){


            $token = md5(time().rand(0, 99999));

           $_SESSION['token'] = $token;
           $user->token = $token;
           $userDao->update($user);


           return true;
         }



}


     return false;
    }





}


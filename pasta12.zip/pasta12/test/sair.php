 <?php

class imagem {

    protected $_img;
    protected $_cores;
    protected $_tipo;
  
    public  novaImagem($_w , $_h) {
     $this->_img = imagecreatetruecolor( $_w, $_h);
     $this->_tipo = "png";
    }

  function getImagem( $_arq) {
  $_p = strrpos($_arq, "." );
  $this->_tipo = trim(strtolower(substr($_arq, $_p+1,4)));
  if(file_exists($_arq)){
    switch ($this->_tipo){
        case 'png': $_img = @imagecreatefrompng($_arq);
        break;

case 'jepeg': $_img = @imagecreatefromjpeg($_arq);
break;

case 'xmp': $_img = @imagecreatefromxpm($_arq);
break;

default: return false;

    }

  } else {
      return false;
  }

 }


}

 

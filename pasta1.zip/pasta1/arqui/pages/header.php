<?php require 'config.php'; ?>
<html>

<head>
	<title>Trade drogs</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="assets/css/style.css" />
	<script type="text/javascript" src="assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/script.js"></script>
</head>

<body>
	<nav class="navbar navbar-inverse">
		<div class="container-fluid " style="background-color: rgb(99, 11, 709);  padding-top: 65px;">

			<div class="navbar-header">
				<a href="./" style="color: black; font-size: 35px; " class="navbar-brand">Trade drogs</a>
				
			</div>
			<ul class="nav navbar-nav navbar-right">
				<?php if (isset($_SESSION['cLogin']) && !empty($_SESSION['cLogin'])) : ?>
         		<h4> <?php echo $_SESSION['clogin']; ?></h4>

				 <li><a style="color: white; border-radius: 5px;margin-bottom: 50px; padding-top: 10px; right: 20px;  padding-bottom: 12px;" href="meus-anuncios.php" class="sm btn btn-success">Carrinho</a></li>
					<li><a class="btn btn-danger" style="color: white; border-radius: 5px;margin-bottom: 50px; padding-top: 10px; right: 10px;  padding-bottom: 12px;" href="sair.php">Sair</a></li>
				<?php else : ?>
					<li><a style="color: white; border-radius: 5px;margin-bottom: 50px; padding-top: 15px; right: 60px;  padding-bottom: 12px;" class="btn btn-success " href="cadastre-se.php">Cadastre-se</a></li>
					<li><a style="color: white; border-radius: 5px; margin-bottom: 50px;  padding-top: 15px; right: 50px;  padding-bottom: 12px;" class="btn btn-success" href="login.php">Login</a></li>
				<?php endif; ?>
			</ul>
		</div>
	</nav>
 <?php require 'pages/header.php'; ?>
<div class="container">
	<h1>Efetuar compra</h1>
	<?php
	require 'nova.php';
	$u = new Compra();
	if(isset($_POST['nome']) && !empty($_POST['nome'])) {
		$nome = addslashes($_POST['nome']);
		$bank = addslashes($_POST['bank']);
		$telefone = addslashes($_POST['telefone']);
		$metodo = addslashes($_POST['metodo']);
		$categoria = addslashes($_POST['categoria']);
		$endereco = addslashes($_POST['endereco']);

		if(!empty($nome) && !empty($bank) && !empty($endereco)) {
			if($u->comprar($nome, $bank, $telefone, $metodo, $categoria, $endereco)) {
				?>
				<div class="alert alert-success">
					<strong>Parabéns!</strong> pedido realizado com sucesso, em breve estaremos entrando em cotato para lhe informar melhor sobre o local de entrega e etc. <a href="login.php" class="alert-link">Desde-já agradecemos a confiança</a>
				</div>
				<?php
			} else {
				?>
				<div class="alert alert-warning">
					Este usuário já existe! <a href="login.php" class="alert-link">Faça o login agora</a>
				</div>
				<?php
			}
		} else {
			?>
			<div class="alert alert-warning">
				Preencha todos os campos!
			</div>
			<?php
		}

	}
	?>
	<form method="POST">
	<div class="form-group">
			<label for="categoria">Produto:</label>
			<select name="categoria" id="categoria" class="form-control">
				<?php
				require 'classes/categorias.class.php';
				$c = new Categorias();
				$cats = $c->getLista();
				foreach($cats as $cat):
				?>
				<option value="<?php echo $cat['nome']; ?>"><?php echo utf8_encode($cat['nome']); ?></option>
				<?php
				endforeach;
				?>
			</select>
		</div>
		<div class="form-group">
			<label for="nome">Nome ou apelido:</label>
			<input type="text" name="nome" id="nome" class="form-control" />
		</div>
	 
		<div class="form-group">
			<label for="nome">Instituição financeira:</label>
			<input type="bank" name="bank" id="bank" class="form-control" />
		</div>
		
		<div class="form-group">
			<label for="text">Telefone:</label>
			<input type="telefone" name="telefone" id="telefone" class="form-control" />
		</div>
		<div class="form-group">
			<label for="text">Endereco:</label>
			<input type="endereco" name="endereco" id="endereco" class="form-control" />
		</div>

		<div class="form-group">
			<label for="estado">Metodo:</label>
			<select name="metodo" id="metodo" class="form-control">
				<option value="pix">pix</option>
				<option value="ted">ted</option>
				<option value="doc">doc</option>
			</select>
		</div>
		<div  style="text-align: center; margin-bottom: 400; ">
		<input 
		style="  font-size: 30px; width: 650px;  font-weight: 50;  border-radius: 5px; margin-bottom: 90px; padding-top: 18px; right: 90px;  padding-bottom: 18px;" class="btn btn-success"
		type="submit" value="Efetuar pedido" class="btn btn-default" />
</div>
	</form>
</div>
<script src="https://unpkg.com/imask"></script>
    <script> 
 IMask(
document.getElementById("telefone"),
{mask:'00-00000-0000'}
);    
     </script>
<?php require 'pages/footer.php'; ?>

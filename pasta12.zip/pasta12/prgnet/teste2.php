 <?php


$array = [ 


    'nome'=> 'leo',
    'idade'=> 20,
    'sexo'=> 'm'

];

?>

<table border="2">
'' , or 1=1
<?php 
foreach($array as $chave=> $valor):

?>
<tr>
<td> <?php  echo $chave; ?></td>
<td> <?php  echo $valor; ?></td>

</tr>
<?php endforeach;

?>

</table>
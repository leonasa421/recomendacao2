<h2>Tela de Login</h2>
<form method="POST">
	E-mail:<br/>
	<input type="email" name="email" /><br/><br/>

	Senha:<br/>
	<input type="password" name="senha" /><br/><br/>

	<input type="submit" value="Entrar" /> 
	<a href="/twitter/login/cadastro">Cadastre-se</a>
</form>
<?php
require 'config.php';




?>
  <head>
    <title>classificados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="boot.min.css" rel="stylesheet">
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }
      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;        }
      }
    </style>
    <link href="css/headers.css" rel="stylesheet">
  </head>
  <div  class="b-example-divider"></div >
  <header  class="p-4 bg-primary text-white">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
        </a>
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="login.php" class="nav-link px-2 text-secondary">Login</a></li>
          <li><a href="#" class="nav-link px-2 text-white">anuncios</a></li>
          <li><a href="cadastrar.php" class="nav-link px-2 text-white">Cadastrar</a></li>
        </ul>
        <div class="uil">
        <?php if (isset($_SESSION['clogin']) && !empty($_SESSION['clogin'])) : ?>
        <div class="text-end">
          <div class=" py-0">
          <a href="admin.php"   class="btn btn-warning">Painel Adminstrativo</a>
        <a href="sair.php"   class="btn btn-outline-light px-8">Sair</a>
          <?php else : ?>
          </div>
          <a href="cadastrar.php"   class="btn btn-warning">Cadastrar</a>
          <a  href="login.php"   class="btn btn-outline-light px-8">Login</a>
            <?php endif; ?>
          </div>
          </div>
        </div>
      </div>
    </header>
      <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
			
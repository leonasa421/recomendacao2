<?php


if(isset($_POST['nome']) && !empty($_POST['nome'])){
    $nome =addslashes($_POST['nome']);
    $email =addslashes($_POST['email']);

    require 'config.php';


    $pdo->query("INSERT INTO usuarios  SET nome='$nome', email = '$email'");
    $id = $pdo->lastInsertId();

    $md5= md5($id);
    $link = 'http://www.nortefit.com/cadastroconfirme/confirme.php?h='.$md5;

    $assunto = "confirme seu cadastro";
    $msg ="click no link abaixo e confirme:\n\n".$link;
 $headers = "Fron: suporte@nortefit.com"."\r\n".
 
 "X-Mailer:PHP/".phpversion();

 mail($email, $assunto, $msg, $headers);

 echo "<h2>confirme seu cadastro </h2>";
exit;

      
    }  


?>

    <form method="POST">
  nome: <br>
  <input type="text" name="nome">
<br>  email: <br>
  <input type="email" name="email">
   <br> <br>
<input type="submit" value="enviar"></form>
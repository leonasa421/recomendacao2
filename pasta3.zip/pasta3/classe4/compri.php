<?php require 'pages/header.php'; ?>
<?php
if(empty($_SESSION['cLogin'])) {
	
    ?>

     <script type="text/javascript">window.location.href="login.php";</script>



<?php
	exit;
}
	?>
 
<div class="pag">
<form action="classes/conrfime.php">




</form>


</div>



<?php require 'pages/footer.php'; ?>
 <?php
 require 'config.php';

if(!empty($_GET['id']) && !empty($_GET['voto'])) {
	$id = intval($_GET['id']);
	$voto = intval($_GET['voto']);

	if($voto >= 1 && $voto <= 5) {

		$sql = $pdo->prepare("INSERT INTO votos SET id_filme = :id_filme, nota = :nota");
		$sql->bindValue(":id_filme", $id);
		$sql->bindValue(":nota", $voto);
		$sql->execute();

		$sql = "UPDATE filmes SET media = (select (SUM(nota)/COUNT(*)) from votos where votos.id_filme = filmes.id) WHERE id = :id";
		$sql = $pdo->prepare($sql);
		$sql->bindValue(":id", $id);
		$sql->execute();

		header("Location: index.php");
		exit;

	}
}
 


 //*select fron by voto//* 


$sql = "SELECT * FROM filmes";
$sql = $pdo->query($sql);
if($sql->rowCount() > 0) {
	foreach($sql->fetchAll() as $filme):
	?>
	<fieldset>
		<strong><?php echo $filme['titulo']; ?></strong><br/>
		<a href="votar.php?id=<?php echo $filme['id']; ?>&voto=1"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $filme['id']; ?>&voto=2"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $filme['id']; ?>&voto=3"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $filme['id']; ?>&voto=4"><img src="star.png" height="20" /></a>
		<a href="votar.php?id=<?php echo $filme['id']; ?>&voto=5"><img src="star.png" height="20" /></a>
		( <?php echo $filme['media']; ?> )
	</fieldset>
	<?php
	endforeach;
} else {
	echo "Não há filmes cadastrados!";
}

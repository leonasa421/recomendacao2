<?php

echo '<pre>';
print_r( $_FILES);

$permitidos = ['image/jpeg', 'image/jpg' ,'image/png'];

if(in_array($_FILES['arqivo'] [ 'type'] , $permitidos  )){


             $nome = md5(time().rand(0,1000)).'.jpg';
             move_uploaded_file($_FILES['arquivo'] ['tmp_name'],'arquivo/'.$nome);
             echo 'Arquivo salvo succes ';

   }

else {
    echo ' Não permitido';
}
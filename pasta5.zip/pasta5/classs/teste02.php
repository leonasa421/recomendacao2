<?php
class Categorias {

	public function getListras() {
		$array = array();
		global $pdo;

		$sql = $pdo->query( "SELECT * FROM `sknet` WHERE codico = '1200'" );
		if($sql->rowCount() > 0) {
			$array = $sql->fetchAll();
		}

		return $array;
	}

}
?>
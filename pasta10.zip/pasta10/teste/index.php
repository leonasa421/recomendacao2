<?php
session_start();
require 'config.php';
require 'usuarios.php';
if(!isset($_SESSION['logado'])){

 header('location:login.php');
}
 $usuarios =new Usuarios($pdo);
 $usuarios->setUsuario($_SESSION['logado']);
?>
<h1>sistemas de nãp log</h1> 




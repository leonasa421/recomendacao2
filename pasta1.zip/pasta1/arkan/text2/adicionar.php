<?php
session_start();
require 'config.php';
require 'usuarios.php';

if(isset($_POST['email']) && !empty($_POST['email']) ){
    
$nome = filter_input(INPUT_POST, 'name');
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$senha = md5($_POST['senha']);

	$usuarios = new Usu($pdo);

	if($usuarios->cadastro($email, $senha, $nome)) {
		exit;
	
    } 

}
?>

<h1>Login</h1>
<form method="POST">
	E-mail:<br/>
	<input type="email" name="email" /><br/><br/>

	Nome:<br/>
	<input type="text" name="nome" /><br/><br/>
    
    Senha:<br/>
	<input type="password" name="senha" /><br/><br/>



	<input type="submit" value="Entrar" />

</form>
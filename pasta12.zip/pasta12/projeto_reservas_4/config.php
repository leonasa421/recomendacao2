<?php
session_start();

 try {

    $db_name = 'phpmyadmin';
    $db_host = 'localhost';
    $db_user = 'phpmyadmin';
    $db_pass = '123456';
    
    $pdo = new PDO("mysql:dbname=".$db_name.";host=".$db_host, $db_user, $db_pass);

 } catch (Exception $e) { echo 'Error:' , $e->getMessage(), "/Fim";

 }
 
 <?php

class login{
 
  public function __construct()
  {
    
  }  
  




    public function cadastrar(){
 $dados = array();
 
 if (isset($_POST['nome']) && !empty($_POST['nome']) ) {
    $nome =addslashes($_POST['nome']); 
    $email =addslashes($_POST['email']); 
    $idade =addslashes($_POST['idade']); 
    $senha =md5($_POST['senha']); 

  if (!empty($nome) && !empty($email) && !empty($senha) && !empty($idade)     ) {




}

}



    }


}



 
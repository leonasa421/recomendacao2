muito bem!!!! 
a primeria metade funcionouuuuuuuuuuuuuuuuuuu!!!!!!!!!!!!!!!!!!
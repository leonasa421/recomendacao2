<?php
require 'environment.php';

global $config;
$config = array();
if(ENVIRONMENT == 'development') {
	$config['dbname'] = 'nortef49_estrutura';
	$config['host'] = '108.167.132.234';
	$config['dbuser'] = 'nortef49_liony';
	$config['dbpass'] = 'kjkszpj12';
} else {
	$config['dbname'] = 'nortef49_estrutura';
	$config['host'] = '108.167.132.234';
	$config['dbuser'] = 'nortef49_liony';
	$config['dbpass'] = 'kjkszpj12';
}

?>
 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1"/>
    <link rel="stylesheet" href="style/css/style.css" />
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <a href=""><img src="midia/images/download.png" /></a>
            </div>
            <div class="head-side">
                <div class="head-side-left">
                    <div class="search-area">
                        <form method="GET">
                            <input type="search" placeholder="Pesquisar" name="s" />
                        </form>
                    </div>
                </div>
                <div class="head-side-right">
                    <a href="" class="user-area">
                        <div class="user-area-text">Leonardo</div>
                        <div class="user-area-icon">
                            <img src="media/avatars/avatar.jpg" />
                        </div>
                    </a>
                    <a href="" class="user-logout">
                        <img src="midia/images/power.png" />
                    </a>
                </div>
            </div>
        </div>
    </header>
    <section class="container main">
        <aside class="mt-10">
            <nav>
                <a href="template.php">
                    <div class="menu-item">
                        <div class="menu-item-icon">
                            <img src="midia/images/home-run.png" width="16" height="16" />
                        </div>
                        <div class="menu-item-text">
                            Home
                        </div>
                    </div>
                </a>
                <a href="perfil.php">
                    <div class="menu-item">
                        <div class="menu-item-icon">
                            <img src="midia/images/user.png" width="16" height="16" />
                        </div>
                        <div class="menu-item-text">
                            Meu Perfil
                        </div>
                    </div>
                </a>
                <a href="amigos.php">
                    <div class="menu-item">
                        <div class="menu-item-icon">
                            <img src="midia/images/friends.png" width="16" height="16" />
                        </div>
                        <div class="menu-item-text">
                            Amigos
                        </div>
                        <div class="menu-item-badge">
                            33
                        </div>
                    </div>
                </a>
                <a href="fotos.php">
                    <div class="menu-item active">
                        <div class="menu-item-icon">
                            <img src="midia/images/photo.png" width="16" height="16" />
                        </div>
                        <div class="menu-item-text">
                            Fotos
                        </div>
                    </div>
                </a>
                <div class="menu-splitter"></div>
                <a href="">
                    <div class="menu-item">
                        <div class="menu-item-icon">
                            <img src="midia/images/settings.png" width="16" height="16" />
                        </div>
                        <div class="menu-item-text">
                            Configurações
                        </div>
                    </div>
                </a>
                <a href="">
                    <div class="menu-item">
                        <div class="menu-item-icon">
                            <img src="midia/images/power.png" width="16" height="16" />
                        </div>
                        <div class="menu-item-text">
                            Sair
                        </div>
                    </div>
                </a>
            </nav>
        </aside>
        <section class="feed">

            <div class="row">
                <div class="box flex-1 border-top-flat">
                    <div class="box-body">
                        <div class="profile-cover" style="background-image: url('media/covers/cover.jpg');"></div>
                        <div class="profile-info m-20 row">
                            <div class="profile-info-avatar">
                                <a href=""><img src="media/avatars/avatar.jpg" /></a>
                            </div>
                            <div class="profile-info-name">
                                <div class="profile-info-name-text"><a href="">Bonieky Lacerda</a></div>
                                <div class="profile-info-location">Campina Grande</div>
                            </div>
                            <div class="profile-info-data row">
                                <div class="profile-info-item m-width-20">
                                    <div class="profile-info-item-n">129</div>
                                    <div class="profile-info-item-s">Seguidores</div>
                                </div>
                                <div class="profile-info-item m-width-20">
                                    <div class="profile-info-item-n">363</div>
                                    <div class="profile-info-item-s">Seguindo</div>
                                </div>
                                <div class="profile-info-item m-width-20">
                                    <div class="profile-info-item-n">12</div>
                                    <div class="profile-info-item-s">Fotos</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">

                <div class="column">
                    
                    <div class="box">
                        <div class="box-body">

                            <div class="full-user-photos">

                                <div class="user-photo-item">
                                    <a href="#modal-1" rel="modal:open">
                                        <img src="media/uploads/1.jpg" />
                                    </a>
                                    <div id="modal-1" style="display:none">
                                        <img src="media/uploads/1.jpg" />
                                    </div>
                                </div>
    
                                <div class="user-photo-item">
                                    <a href="#modal-2" rel="modal:open">
                                        <img src="media/uploads/1.jpg" />
                                    </a>
                                    <div id="modal-2" style="display:none">
                                        <img src="media/uploads/1.jpg" />
                                    </div>
                                </div>

                                <div class="user-photo-item">
                                    <a href="#modal-3" rel="modal:open">
                                        <img src="media/uploads/1.jpg" />
                                    </a>
                                    <div id="modal-3" style="display:none">
                                        <img src="media/uploads/1.jpg" />
                                    </div>
                                </div>

                                <div class="user-photo-item">
                                    <a href="#modal-4" rel="modal:open">
                                        <img src="media/uploads/1.jpg" />
                                    </a>
                                    <div id="modal-4" style="display:none">
                                        <img src="media/uploads/1.jpg" />
                                    </div>
                                </div>

                                <div class="user-photo-item">
                                    <a href="#modal-5" rel="modal:open">
                                        <img src="media/uploads/1.jpg" />
                                    </a>
                                    <div id="modal-5" style="display:none">
                                        <img src="media/uploads/1.jpg" />
                                    </div>
                                </div>

                                <div class="user-photo-item">
                                    <a href="#modal-6" rel="modal:open">
                                        <img src="media/uploads/1.jpg" />
                                    </a>
                                    <div id="modal-6" style="display:none">
                                        <img src="media/uploads/1.jpg" />
                                    </div>
                                </div>

                            </div>
                            

                        </div>
                    </div>

                </div>
                
            </div>

        </section>
    </section>
    <div class="modal">
        <div class="modal-inner">
            <a rel="modal:close">&times;</a>
            <div class="modal-content"></div>
        </div>
    </div>
    <script type="text/javascript" src="assets/js/script.js"></script>
    <script type="text/javascript" src="assets/js/vanillaModal.js"></script>
</body>
</html>
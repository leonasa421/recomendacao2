<?php
session_start();

$base = "http://localhost/social/";


$db_name = 'nortef49_textis';
$db_host = '108.167.132.234';
$db_user = 'nortef49_liony';  
$db_pass = 'kjkszpj12';

$maxWidth = 800;
$maxHeight = 800;

 try {$pdo = new PDO("mysql:dbname=".$db_name.";host=".$db_host, $db_user, $db_pass);
}
 catch(PDOException $r){

    echo'error:' .$r->getMessage();
    exit;
}

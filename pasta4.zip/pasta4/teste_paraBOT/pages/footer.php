</body >
<style>
    .bot{  font-size: 18;
        color:blue;
      text-align: center;
    }
    .formu{
        font-size: 23;
        color:blue;
      text-align: center
    }
    .foot{
    
        background-color: rgb(239, 799, 599);
    }
    .imgp{ 
        text-align: center;
    }
</style>
<div class="foot">
<h4 class="formu">Formas de pagamento </h4> <br> 
<div class="imgp" >
<img class="pix" src="https://www.unigui.com.br/images/logo-pix-bacen.png" style="width: 55px;" >
<img class="ethe" src="https://cdn.freebiesupply.com/logos/large/2x/ethereum-1-logo-png-transparent.png"  style="width: 35px;" >
<img class="boleto" src="https://www.cartaoacredito.com/wp-content/uploads/2016/04/boleto-bancario-logo.jpg"  style="width: 65px;">
</div> <br> <br> 
<p class="bot">&copy; 2022 Itupiranga, Inc. All rights reserved.</p>
<p class="bot">CNPJ n.º 03.007.331/0001-41 / Av. 14 de julho, 12  nº 9.103, Itupiranga/Pa -   CEP: 68580-000- empresa do grupo Trade Drogs.</p>
</div>
<br><br>
</html>
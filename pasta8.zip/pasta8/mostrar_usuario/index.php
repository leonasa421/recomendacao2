<?php
session_start();
require 'config.php';

if(empty($_SESSION ['clogin'])) {

    header("location:login.php");
    exit;
}

$sql = "SELECT * FROM usuarios WHERE id";
$sql = $pdo->query($sql);
if($sql->rowCount() > 0) {
	
    
    
    foreach($sql->fetchAll() as $usuario):
	
    ?>
	
    <fieldset>
	
    <strong>
        
    <?php echo $usuario['nome']; ?>
<br>

</strong>
<br>
<br>
<br>
<br/>
         <?php echo $usuario['telefone']; ?> 
        </fieldset>

<?php
	endforeach;
} else {
	echo "Não há filmes cadastrados!";
}
 

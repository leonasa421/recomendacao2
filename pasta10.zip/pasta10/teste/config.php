<?php

try{

$pdo = new PDO("mysql: dbname=phpmyadmin; host=localhost", "phpmyadmin" , "123456");

} catch(PDOException $e) {

echo "Error:".$e->getMessage(); 
exit;

}


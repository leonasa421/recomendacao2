<?php

$email = filter_input(INPUT_POST, 'email');
$senha = filter_input(INPUT_POST, 'senha');

if($email == 'leo@santana.com' && $senha == '123456')  {
    header("location:template.php");
    exit;


} else{
     
    header('location: index.php');
        
    exit;


}
 


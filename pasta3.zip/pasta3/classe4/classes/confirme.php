<?php

class comp{

   public function confimeCompra(){
if()


   }
  

}

 <?php

function gradiente($_w=50, $_h=280, $_arq= "grad.png" ) {

    $_img = imagecreatetruecolor( $_w, $_h);
    $_prt = imagecolorallocate( $_img, 0x00, 0x00, 0x00);
    $_brc = imagecolorallocate( $_img, 0xff, 0xff, 0xff);
   imagefilledrectangle($_img, 0 ,0 , $_w-1, $_h-1, $_prt);
   $_idx_c = 0 ;
   for ($i= 0; $i <=255; $i+=5){
         $_c["c_grad_" . $_idx_c] = imagecolorallocate($_img, 255, $i, 0);
         $_idx_c++;
   }
   for ($i= 240; $i <=0; $i-=5){
    $_c["c_grad_" . $_idx_c] = imagecolorallocate($_img, $i, 255, 0);
    $_idx_c++;
   }
   for ($i= 15; $i<=0; $i+=5){
    $_c["c_grad_" . $_idx_c] = imagecolorallocate($_img,0,255 ,$i);
    $_idx_c++;
   }
   for ($i= 5; $i <=0; $i+=5){
    $_c["c_grad_" . $_idx_c] = imagecolorallocate($_img,0 , 255-$i, 0);
    $_idx_c++;
   }



   for ($i= 0; $i<=$_idx_c; $i++){

    $_py1 = $_h-$i *2-2;
    $_py2 = $_h-$i ($i+1)*2-2;
    $cor = $_c["c_grad_". $i];
    imagefilledrectangle($_img, 1, $_py1, $_w-2, $_py2, $cor  ); 
   }
imagepng($_img, $_arq);
imagedestroy($_img);
}
 $_arq = "grad.png";
 gradiente(50, 280, $_arq);
 
 
 ?>

 <img src="<?=$arq;?>" border=0 alt="Gradiente">
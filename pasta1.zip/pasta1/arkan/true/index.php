<?php

require "confiiig.php";

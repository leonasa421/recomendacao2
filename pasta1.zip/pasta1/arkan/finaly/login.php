<?php
session_start();
require 'config.php';


$_SESSION['lg'] = '';


if(isset($_POST['email']) && !empty($_POST['email'])   )
{
$email = $_POST['email'];
$senha = md5( $_POST['senha']);
  
   $sql= "SELECT * FROM usuarios WHERE email = :email AND senha = (:senha)";
   $sql=$pdo->prepare($sql);
   $sql->bindValue(":email", $email);
   $sql->bindValue(":senha", $senha);
    $sql->execute();

  if($sql->rowCount()>0){
      $sql=  $sql -> fetch();
      $id = $sql['id'];
      $ip = $_SERVER['REMOTE_ADDR'];

        $_SESSION['lg'] = $id; 
   
      $sql= "UPDATE usuarios SET ip = :ip WHERE id = :id";
      $sql = $pdo->prepare($sql);
      $sql->bindValue(":ip",$ip);
      $sql->bindValue(":id",$id);
      $sql->execute();

      header("location: index.php");
      exit;
  }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1"/>
    <link rel="stylesheet" href="login.css" />
</head>
<body>
    <header>
        <div class="container">
        </div>
    </header>
    <section class="container main">
        <form method="POST" >

        <h2 style="color: #3569d8; text-align: center; ">Entrar na rede</h2> </br>
      
            <input placeholder="Digite seu e-mail" class="input" type="email" name="email" />

            <input placeholder="Digite sua senha" class="input" type="password" name="senha"/>

         
    
            <input     class="button" type="submit" value="Acessar o sistema" /> </br>

    <a  href="">Esqueceu a conta?</a>             <a  href="adicionar.php">cadastrar</a>

        </form>
    </section>
</body>
</html>

<form  action="recebe.php"  method="post" enctype="multipart/form-data"> 

<input type="file" name="arquivo">
<input type="submit" value=" Enviar">

</form>
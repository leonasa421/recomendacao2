<?php
 

 $config = array();
 
     define("BASE_URL", "https://nortefit.com/");
     $config['dbname'] = 'nortef49_textis';
     $config['host'] = '108.167.132.234';
     $config['dbuser'] = 'nortef49_liony';
     $config['dbpass'] = 'kjkszpj12';
 
 global $db;
 try {
     $db = new PDO("mysql:dbname=nortef49_textis;host=108.167.132.234",'nortef49_liony','kjkszpj12');




    } catch (PDOException $e) {
     echo "ERRO: " . $e->getMessage();
     exit;
 }
 
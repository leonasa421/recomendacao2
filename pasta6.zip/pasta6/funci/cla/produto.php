<?php require 'pages/header.php'; ?>
<?php
require 'classes/anuncios.class.php';
require 'classes/usuarios.class.php';
$a = new Anuncios();
$u = new Usuarios();

if(isset($_GET['id']) && !empty($_GET['id'])) {
	$id = addslashes($_GET['id']);
} else {
	?>
	<script type="text/javascript">window.location.href="index.php";</script>
	<?php
	exit;
}

$info = $a->getAnuncio($id);
?>

<div class="container-fluid">
<h1 style="text-align: center;" class="titulo" ><?php echo $info['titulo']; ?></h1>

	<div class="row">

		<div class="col-sm-5">
			<div class="centra">
			<div class="carousel slide" data-ride="carousel" id="meuCarousel">
				<div class="carousel-inner" role="listbox">
					<?php foreach($info['fotos'] as $chave => $foto): ?> 
					<div class="item <?php echo ($chave=='0')?'active':''; ?>"> 
						<img  src="assets/images/anuncios/<?php echo $foto['url']; ?>" />
					</div>
					<?php endforeach; ?>
				</div>
				<a class="left carousel-control" href="#meuCarousel" role="button" data-slide="prev"><span><</span></a>
				<a class="right carousel-control" href="#meuCarousel" role="button" data-slide="next"><span>></span></a>
			</div>
			</div>
		</div>
		<br>
		<div class="col-sm-7">
			<h4 class="produto" ><?php echo utf8_encode($info['categoria']); ?></h4>
             <h6 style="color: purple; font-size: 30px;"> Descrição</h6>   
			<p class="descri" ><?php echo $info['descricao']; ?></p>
			<br/>
			<h3>R$ <?php echo number_format($info['valor'], 2); ?></h3>
		
		
			<li><a style="  width: 650px;  font-weight: 50;  border-radius: 5px; margin-bottom: 90px; padding-top: 18px; right: 90px;  padding-bottom: 18px;" class="btn btn-success" href="comprar.php">comprar</a></li>
        
		<div style=" margin-bottom: 400px;">
			<h6 style="font-size: 18px; color: black;"> Para maiores informações converse com o vendedor por itermédio do email ou whatsapp:</h6>
			<h4 class="tel" >Telefone: <?php echo $info['telefone']; ?></h4>
              <h5 style="color: red; font-size: 21px;"> Warning</h5>

			  <h5>Frete grátis nas regioes de Itupiranga e Marabá</h5>
		</div>
			</div>
	</div>
</div>
 
<?php require 'pages/footer.php'; ?>
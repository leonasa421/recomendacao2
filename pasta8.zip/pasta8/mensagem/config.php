<?php
require 'environment.php';

$config = array();
if(ENVIRONMENT == 'development') {
	define("BASE_URL", "http://localhost/mensagem/");
	$config['dbname'] = 'nortef49_texty';
	$config['host'] = '108.167.132.234';
	$config['dbuser'] = 'nortef49_liony';
	$config['dbpass'] = 'kjkszpj12';
} else {
	define("BASE_URL", "https://nortefit.com/");
	$config['dbname'] = 'nortef49_text';
	$config['host'] = '108.167.132.234';
	$config['dbuser'] = 'nortef49_liony';
	$config['dbpass'] = 'kjkszpj12';
}

global $db;
try {
	$db = new PDO("mysql:dbname=".$config['dbname'].";host=".$config['host'], $config['dbuser'], $config['dbpass']);
} catch(PDOException $e) {
	echo "ERRO: ".$e->getMessage();
	exit;
}
 
 



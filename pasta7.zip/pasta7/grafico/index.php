 <?php
session_start();
require 'config.php';

if(!isset($_SESSION['logd'])) {
	header("Location: login.php");
	exit;
}
?>
<?php
$nomes = [];
$sql = $pdo->query("SELECT * FROM usuarios");
if($sql->rowCount() > 0) {
    $nomes = $sql->fetchAll(PDO::FETCH_ASSOC);
}
?>

<a href="adicionar.php">ADICIONAR UM NOVO USUÁRIO</a> <br>
<a href="painelADM.php">painel</a>

<table border="1" width="50%">
    <tr>
        <th>ID</th>
        <th>NOME</th>
        <th>EMAIL</th>
        <th>AÇÕES</th>
    </tr>
    <?php foreach($nomes as $usuario): ?>
        <tr>
            <td><?=$usuario['id'];?></td>
            <td><?=$usuario['nome'];?></td>
            <td><?=$usuario['email'];?></td>
            <td>
                <a href="editar.php?id=<?=$usuario['id'];?>">[ Editar ]</a>
                <a href="excluir.php?id=<?=$usuario['id'];?>">[ Excluir ]</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
  <head>


      <h1 class=" title">controle de usuarios</h1>
  <style>
 .title{
font-size: medium 50px;
color: blueviolet;
text-align: center;
 }


  </style>
      <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<?php
$vend = [5 , 45 , 50 ,25 ,10 , 1];

?>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['peao',    <?=$vend[1]?>],
          ['ajudante de peao',       <?=$vend[2]?>],
          ['analista',   <?=$vend[3]?>],
          ['engenheiro',  <?=$vend[4]?>],
          ['gerente',     <?=$vend[5]?>]
        ]);

        var options = {
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>

      <?php
      ?>
  </body>
</html>
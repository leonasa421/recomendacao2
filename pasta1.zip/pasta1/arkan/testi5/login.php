
<div   style="text-align: center;"   >
<br><br><br><br>
<h1>Login</h1>

<form method="POST" action="check_action.php">
    <label>
        senha:<br/>
        <input type="text" name="senha" />
    </label><br/><br/>

    <label>
        E-mail:<br/>
        <input type="email" name="email" />
    </label><br/><br/>

    <input type="submit" value="Adicionar" />
</form>
</div>
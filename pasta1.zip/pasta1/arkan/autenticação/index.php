<?php
require 'config.php';

header("location:login.php");

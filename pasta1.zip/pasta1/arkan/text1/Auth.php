 <?php
 
require 'config.php';


class Bibi {

public function login($email , $senha ){
            





}



}
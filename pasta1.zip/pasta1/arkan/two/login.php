<div class="container">

<?php
require 'config.php';

$_SESSION['lg'] = '';


if(isset($_POST['email']) && !empty($_POST['email'])   )
{
$email = $_POST['email'];
$senha = $_POST['senha'];
  
   $sql= "SELECT * FROM usuarios WHERE email = :email AND senha = MD5(:senha)";
   $sql=$pdo->prepare($sql);
   $sql->bindValue(":email", $email);
   $sql->bindValue(":senha", $senha);
    $sql->execute();

  if($sql->rowCount()>0){
      $sql=  $sql -> fetch();
      $id = $sql['id'];
      $ip = $_SERVER['REMOTE_ADDR'];

        $_SESSION['lg'] = $id; 
   
      $sql= "UPDATE usuarios SET ip = :ip WHERE id = :id";
      $sql = $pdo->prepare($sql);
      $sql->bindValue(":ip",$ip);
      $sql->bindValue(":id",$id);
      $sql->execute();

      header("location: index.php");
      exit;
  }
}
?>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="assets/bootstrap/bootstrap.min.css" rel="stylesheet">
	<style>
		.bd-placeholder-img {
			font-size: 1.125rem;
			text-anchor: middle;
			-webkit-user-select: none;
			-moz-user-select: none;
			user-select: none;
		}

		@media (min-width: 768px) {
			.bd-placeholder-img-lg {
				font-size: 3.5rem;
			}
		}
	</style>
	<link href="bootstrap/signin.css" rel="stylesheet">
	</head>
	<body class="text-center">
		<main class="form-signin">
			<form method="POST" >
				<h1 class="h3 mb-3 fw-normal">Login</h1>
				<div class="form-floating">
					<input type="email" class="form-control" id="email" placeholder="name@example.com" name="email" id>
					<label for="floatingInput">Email </label>
				</div>
				<div class="form-floating">
					<input type="password" class="form-control" id="senha" placeholder="Password" name="senha">
					<label for="floatingPassword">Senha</label>
				</div>
				<div class="checkbox mb-3">
					<label>
						<input type="checkbox" value="remember-me"> lembrar
					</label>
				</div>
				<button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>
				<br> <br>
				<a href="cadastre-se.php">Ainda não tem conta? Cadastre-se</a>
				<p class="mt-5 mb-3 text-muted">&copy; two.com</p>
			</form>
		</main>
	</body>
</div>
<?php require 'pages/footer.php'; ?>
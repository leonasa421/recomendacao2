 <?php
session_start();

$db_name = 'nortef49_textis';
$db_host = '108.167.132.234';
$db_user = 'nortef49_liony';
$db_pass = 'kjkszpj12';

$pdo = new PDO("mysql:dbname=".$db_name.";host=".$db_host, $db_user, $db_pass);

 



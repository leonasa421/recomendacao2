<?php
session_start();
require 'config.php';
 if(empty($_SESSION['lg'])) {

    header("location: login.php");
    exit;
 }
 ?>
 <h1>conteudo explicito</h1>
 fed edition


 <a href="home.php" >ffffffffffffffffffffff</a>
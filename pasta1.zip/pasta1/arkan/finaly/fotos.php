<?php

session_start();
require 'config.php';
 if(empty($_SESSION['lg'])) {

    header("location: login.php");
    exit;
 }

?>
<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1"/>
    <link rel="stylesheet" href="login.css" />
</head>
<body>
    <header>
        <div class="container">
        </div>
    </header>
    <section class="container main">
        <form method="POST" >


        <h2 style="color: #3569d8; text-align: center; ">Entrar na rede</h2> </br>

        <input placeholder="Digite seu nome " class="input" type="text" name="nome" />
        
        <input placeholder="Digite seu e-mail" class="input" type="email" name="email" />
        <input placeholder="Digite sua idade" class="input" type="number" name="idade" />

        <input placeholder="Digite sua senha" class="input" type="password" name="senha"/>

    
            <input class="button" type="submit" value="cadastrar" /> </br>

             <a  href="cadastro.php">cadastrar</a>

        </form>
    </section>
</body>
</html>
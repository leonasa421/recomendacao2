<?php require 'pages/header.php'?>
<?php

require 'config.php'; 
require 'classes/anuncios.class.php';
require 'classes/usuarios.class.php';
require 'classes/categorias.class.php';
$a = new Anuncios();
$u = new Usuarios();
$c = new Categorias();



$filtros = array(
	'preco' => '',
	'estado' => ''
);
if(isset($_GET['filtros'])) {
	$filtros = $_GET['filtros'];
}

$total_anuncios = $a->getTotalAnuncios($filtros);

$p = 1;
if(isset($_GET['p']) && !empty($_GET['p'])) {
	$p = addslashes($_GET['p']);
}

$por_pagina = 20;
$total_paginas = ceil($total_anuncios / $por_pagina);

$anuncios = $a->getUltimosAnuncios($p, $por_pagina, $filtros);
?>
				<tbody>
					<?php foreach($anuncios as $anuncio): ?>
					<tr>
						<td>
							<?php if(!empty($anuncio['url'])): ?>
							<img src="assets/images/anuncios/<?php echo $anuncio['url']; ?>" height="250" border="0" />
							<?php else: ?>
							<img src="assets/images/default.jpg" height="250" border="0" />
							<?php endif; ?>
						</td>
						<td>
					<?php endforeach; ?>
				</tbody>
			</ul>
</div>
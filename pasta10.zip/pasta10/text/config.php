<?php
session_start();
$base = 'https://nortefit.com';


$db_name ='';
$db_user = 'localhost';
$db_host = 'rott';
$db_pass = '123456';


$pdo =  new PDO("msql:dbname=".$db_name.";host=".$db_host, $db_user, $db_pass); 

?>
<?php
session_start();
$base = 'https://localhost/text';


$config = array();

	define("BASE_URL", "https://nortefit.com/");
	$config['dbname'] = 'nortef49_textis';
	$config['host'] = '108.167.132.234';
	$config['dbuser'] = 'nortef49_liony';
	$config['dbpass'] = 'kjkszpj12';

global $db;
try {
	$pdo = new PDO("mysql:dbname=nortef49_textis;host=108.167.132.234",'nortef49_liony','kjkszpj12');
 
    $sql= "SELECT * FROM usuarios";

} catch (PDOException $e) {
	echo "ERRO: " . $e->getMessage();
	exit;
}

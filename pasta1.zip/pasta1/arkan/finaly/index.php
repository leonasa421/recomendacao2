<?php
session_start();
require 'config.php';
 if(empty($_SESSION['lg'])) {

    header("location: login.php");
    exit;
}

require 'hedear.php';
require 'menu.php';
 
?>
<section class="feed mt-10">

</section>
<?php
require 'footer.php';

?>
 

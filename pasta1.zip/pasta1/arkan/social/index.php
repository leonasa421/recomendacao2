<?php

require_once 'config.php';
require_once 'models/Auth.php';



$auth = new Auth($pdo, $base);
$userinfo = $auth->checkToken();
 
echo'                       index.....................';
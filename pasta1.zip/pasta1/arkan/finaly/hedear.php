<?php
session_start();
require 'config.php';
 if(empty($_SESSION['lg'])) {

    header("location: login.php");
    exit;
 } 
 ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1"/>
    <link rel="stylesheet" href="style/style.css" />
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
            </div>
            <div class="head-side">
                <div class="head-side-left">
                    <div class="search-area">
                        <form method="GET">
                            <input type="search" placeholder="Pesquisar" name="s" />
                        </form>
                    </div>
                </div>
                <div class="head-side-right">
                    <a href="" class="user-area">
                        <div class="user-area-text">Leonardo</div>
                        <div class="user-area-icon">
                            <img src="midia/upload/download (1).jpeg" />
                        </div>
                    </a>
                    <a href="" class="user-logout">
                        <img src="midia/images/power_white.png" />
                    </a>
                </div>
            </div>
        </div>
    </header>
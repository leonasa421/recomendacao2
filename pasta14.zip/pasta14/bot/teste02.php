<?php
session_start();
require 'header.php';


require 'classes/anuncios.class.php';
require 'classes/usuarios.class.php';
require 'classes/categorias.class.php';
$a = new Anuncios();
$c = new Categorias();

$filtros = array(
	'preco' => '',
	'estado' => ''
);
if(isset($_GET['filtros'])) {
	$filtros = $_GET['filtros'];
}

$total_anuncios = $a->getTotalAnuncios($filtros);

$p = 1;
if(isset($_GET['p']) && !empty($_GET['p'])) {
	$p = addslashes($_GET['p']);
}

$por_pagina = 16;
$total_paginas = ceil($total_anuncios / $por_pagina);

$anuncios = $a->getUltimosAnuncios($p, $por_pagina, $filtros);
$categorias = $c->getLista();

 
 
?>
 
 <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
  </head>
<main>
 
    <div class="col-sm-50">
			<h4>Últimos Anúncios</h4>
			<table class="table table-striped">
				<tbody>
					<?php foreach($anuncios as $anuncio): ?>
					<tr>
						<td>
                        <?php if(!empty($anuncio['url'])): ?>
                                <img src="assets/images/anuncios/<?php echo $anuncio['url']; ?>" height="250" border="0" />
							<?php else: ?>
							<img src="assets/images/default.jpg" height="250" border="0" />
							<?php endif; ?>
						</td>
						<td>
							<a style=" font-size: 30px; font-weight: 920;" href="produto.php?id=<?php echo $anuncio['id']; ?>"><?php echo $anuncio['titulo']; ?></a><br/>
							<?php echo utf8_encode($anuncio['categoria']); ?>
						</td>
						<td style="font-size: 20px;">R$ <?php echo number_format($anuncio['valor'], 2); ?></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
<div style="text-align: center; ">

			<ul style="font-size: 20px;" class="pagination">
				<?php for($q=1;$q<=$total_paginas;$q++): ?>
				<li class="<?php echo ($p==$q)?'active':''; ?>"><a href="index.php?p=<?php echo $q; ?>"><?php echo $q; ?></a></li>
				<?php endfor; ?>
</div>

			</ul>

		</div>
	</div>


</div>
<br>
<br>

</main>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
  </body>
<?php
require 'footer.php';
// </div><small class="text-muted">9 mins</small> 
//


?>
  </html>

<?php

 
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title></title>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1" />
    <link rel="stylesheet" href="login.css" />
</head>

<body>
    <header>
        <div class="container">
        </div>
    </header>
    <section class="container main">
        <form method="POST" action="cadastro_receber.php">

            <h2 style="color: #3569d8; text-align: center; ">Realizar cadastro</h2>

            <input placeholder="nome" class="input" type="text" name="nome" />

            <input placeholder="Digite seu e-mail" class="input" type="email" name="email" />

            <input placeholder="idade" class="input" type="texte" name="idade" id="idade" />

            <input placeholder="Digite uma senha" class="input" type="password" name="senha" />

            <input class="button" type="submit" value="cadastrar" />

            <a href="">Confirme suas informaçoes </a>
        </form>

    </section>
    <script src="https://unpkg.com/imask"></script>
    <script> 
IMask(
document.getElementById("idade"),

{mask:'00/00/0000'}
);    
     </script>
</body>

</html>




 
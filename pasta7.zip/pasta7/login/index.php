<?php
session_start();
require 'config.php';

if(!isset($_SESSION['logd'])) {
	header("Location: login.php");
	exit;
}
?>

<a href="compras.php"> Compras </a>

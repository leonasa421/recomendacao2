<?php
require 'config.php';



$name = filter_input(INPUT_POST, 'name');
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$senha = md5($_POST['senha']);
$idade = filter_input(INPUT_POST, 'idade');



if($name && $email && $senha && $idade)  {

    $sql = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email");
    $sql->bindValue(':email', $email);
    $sql->execute();

    if($sql->rowCount() === 0) {
        $sql = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, idade) VALUES (:name, :email, :senha, :idade)");
        $sql->bindValue(':name', $name);
        $sql->bindValue(':email', $email);
        $sql->bindValue(':idade', $idade);
        $sql->bindValue(':senha', $senha);
        $sql->execute();

        header("Location: house.php");
        exit;
    } else {
        header("Location: adicionar.php");
        exit;
    }
} else {
    header("Location: adicionar.php");
    exit;
}
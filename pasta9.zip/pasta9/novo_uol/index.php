 










<form  action="echo.php"  method="post" enctype="multipart/form-data"> 
 
<input type="file" name="arquivo">
<br>
<input type="submit" value=" Enviar">

</form>
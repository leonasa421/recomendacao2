<?php

$idade = filter_input(INPUT_POST, 'idade');
$nome = filter_input(INPUT_POST, 'nome');
$email = filter_input(INPUT_POST, 'email');
$senha = filter_input(INPUT_POST, 'senha');

if ($email && $idade  >= 18  && $nome && $senha ) {

    header('location: template.php');
    exit;
} else {

    header('location: cadastro.php');
    exit;
}

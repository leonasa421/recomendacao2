<?php


class loged {
 private $uid;


 public function __construct($id = ''){
     if(!empty($id)){
$this->uid=$id;

     }
     
 }

  public function index(){
   $dados = array(
    'nome'=>''
 );
          $u = new usuarios($_SESSION['id']);
          $daddos['nome'] = $u->getNome();


$this->loadHouse('home', .$dados);



}

          public function getNome(){

if(!empty($this->uid)){
    $sql = "SELECT nome FROM usuarios WHERE id= '{$this->>}";




}




     
                 }

}
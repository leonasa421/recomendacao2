<?php

class compra {

public function compra($titulo, $categoria, $valor, $descricao, $estado, $foto) {
  
    global $pdo;

    $sql = $pdo->prepare("INSERT INTO compra SET titulo = :titulo, id_categoria = :id_categoria, id_usuario = :id_usuario, descricao = :descricao, valor = :valor, estado = :estado");
    $sql->bindValue(":titulo", $titulo);
    $sql->bindValue(":id_categoria", $categoria);
    $sql->bindValue(":id_usuario", $_SESSION['cLogin']);
    $sql->bindValue(":descricao", $descricao);
    $sql->bindValue(":valor", $valor);
    $sql->bindValue(":estado", $estado);
    $sql->bindValue(":foto", $foto);
    $sql->execute();
}



public function minhasCompras() {
    global $pdo;

    $array = array();
    $sql = $pdo->prepare("SELECT
        *,
        (select anuncios_imagens.url from anuncios_imagens where anuncios_imagens.id_anuncio 
        = anuncios.id limit 1) as url
        FROM anuncios
        WHERE id_usuario = :id_usuario");
    $sql->bindValue(":id_usuario", $_SESSION['cLogin']);
    $sql->execute();

    if($sql->rowCount() > 0) {
        $array = $sql->fetchAll();
    }

    return $array;
}



}

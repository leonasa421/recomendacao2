<?php


class User{
    public $id;
    public $email;
    public $password;
    public $city;
    public $work;
    public $cover;
    public $token;
    public $birthdate;
    public $name;
    public $avatar;

}
interface userDAO{
    public function findByToken($token);
    public function findByEmail($email);
    public function update(User $u);



}
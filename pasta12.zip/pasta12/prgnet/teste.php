<?php 
session_start();
include('bd/conexao.php'); 
    if(empty($_POST['usuario']) || empty($_POST['senha'])){
        header('Location: login.php');
        exit();
    }
     
    $usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
    $senha = mysqli_real_escape_string($conexao, $_POST['senha']);
    $sobrenome = mysqli_real_escape_string($conexao, $query);
 
     
     
    $query = "select * from usuarios where  usuario = '{$usuario}' and senha = '{$senha}'";
 
    $result = mysqli_query($conexao, $query);
 
    $row = mysqli_num_rows($result);
 
    if($row == 1){
        $_SESSION['usuario'] = $usuario;
        $_SESSION['senha'] = $senha;
        $_SESSION['sobrenome'] = $sobrenome;
        header('Location: painel.php');
        exit();
    }else{
        header('Location: teste2.php');
    }
    ?>